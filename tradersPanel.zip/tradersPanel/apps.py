from django.apps import AppConfig


class TraderspanelConfig(AppConfig):
    name = 'tradersPanel'
